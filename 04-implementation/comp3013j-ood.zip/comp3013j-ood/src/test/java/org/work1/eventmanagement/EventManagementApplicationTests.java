package org.work1.eventmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = EventManagementApplication.class)
class EventManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
