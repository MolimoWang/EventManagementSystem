package org.work1.eventmanagement.service;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.work1.eventmanagement.controller.VenueDTO;
import org.work1.eventmanagement.entity.Event;
import org.work1.eventmanagement.entity.Organizer;
import org.work1.eventmanagement.entity.Venue;
import org.work1.eventmanagement.exception.ServiceException;
import org.work1.eventmanagement.repository.OrganizerRepository;
import org.work1.eventmanagement.repository.VenueRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class VenueService {

    @Autowired
    private final VenueRepository venueRepository;
    @Resource
    private OrganizerRepository organizerRepository;

    @Autowired
    private final OrganizerRepository organiserRepository;



    @Autowired
    public VenueService(VenueRepository venueRepository, OrganizerRepository organiserRepository) {
        this.venueRepository = venueRepository;
        this.organiserRepository = organiserRepository;
    }

    // 获取特定场地
    public Venue getVenue(Long venueId) {
        Optional<Venue> venue = venueRepository.findById(venueId);
        return venue.orElseThrow(() -> new IllegalArgumentException("Venue not found with ID: " + venueId));
    }

    // 获取所有场地
    public List<Venue> getVenues() {
        try {
            ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            HttpServletRequest request = servletRequestAttributes.getRequest();
            Object role1 = request.getSession().getAttribute("role");
            if (role1.equals("ORGANIZER")){
                Organizer organizer = (Organizer)request.getSession().getAttribute("username");
                String username = organizer.getUsername();
                // 检查数据库查询或服务方法是否有问题
                Organizer organizer1 = organizerRepository.findByUsername(username);
                return venueRepository.findAllByOrganiserId(organizer1.getId());
            }
            return venueRepository.findAll();


        } catch (Exception e) {
            throw new RuntimeException("Error fetching venues", e);
        }
    }


    // 获取特定组织者的场地
    public List<Venue> getMyVenues(Long organiserId) {
        return venueRepository.findAllByOrganiserId(organiserId);
    }

    @Transactional
    // 创建场地
    // VenueService.java
    public boolean createVenue(VenueDTO venueDTO) throws ServiceException {
        Venue venue = convert(venueDTO);

        //get organizer
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Organizer)) {
            throw new ServiceException("No logged-in organiser found or invalid principal");
        }

        Organizer organiser = (Organizer) authentication.getPrincipal();
        venue.setOrganiser(organiser);

        if (venue.getOrganiser() == null) {
            throw new ServiceException("Organiser must not be null");
        }


        // 省略复杂逻辑，保存到数据库
        // 保存Organizer
        venueRepository.save(venue);

        return true;
    }

    // 解构 VenueDTO 的属性
    private Venue convert(VenueDTO venueDTO) {
        String name = venueDTO.getName();
        String address = venueDTO.getAddress();
        String contactName = venueDTO.getContactName();
        String contactPhoneNumber = venueDTO.getContactPhoneNumber();
        String contactEmail = venueDTO.getContactEmail();
        String ticketTypeName1 = venueDTO.getTicketTypeName1();
        String ticketTypeName2 = venueDTO.getTicketTypeName2();

        String numberAvailable1 = venueDTO.getAvailableNumber1();
        String numberAvailable2 = venueDTO.getAvailableNumber2();

        Venue venue = new Venue();
        // basic
        venue.setId(venueDTO.getId());
        venue.setName(name);
        venue.setAddress(address);
        venue.setContactName(contactName);
        venue.setContactPhoneNumber(contactPhoneNumber);
        venue.setContactEmail(contactEmail);
        // ticket
        venue.setTicketTypeName1(ticketTypeName1);
        venue.setTicketTypeName2(ticketTypeName2);
        venue.setAvailableNumber1(numberAvailable1);
        venue.setAvailableNumber2(numberAvailable2);

        // 日期
        venue.setDate(venueDTO.getDate());
        // time 转换
//        if(!Strings.isBlank(venueDTO.getTime())) {
//            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
//            try {
//                Date timeDate = simpleDateFormat.parse(venueDTO.getTime());
//                LocalDateTime localDate = timeDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
//                venue.setTime(Time.valueOf(localDate.toLocalTime()));
//            } catch (ParseException e) {
//            }
//        }
        return venue;
    }

    // 更新场地
    public boolean updateVenue(Venue venue) {
        getVenue(venue.getId()); // 检查场地是否存在
        // 更新容量（这里简化为直接覆盖原数据）
        venueRepository.save(venue);
        return true;
    }

    // 删除场地
    public Venue deleteVenue(Long venueId) {
        Venue venue = getVenue(venueId); // 检查场地是否存在
        venueRepository.delete(venue);

        return venue;
    }

    // 保存场地
    public boolean saveVenue(Venue venue) {
        venueRepository.save(venue);
        return true;
    }

    // 检查重复场地
    public void checkDuplicateVenue(Venue venue) {
        List<Venue> allVenues = venueRepository.findAll();
        boolean isDuplicate = allVenues.stream().anyMatch(existingVenue ->
                existingVenue.getName().equalsIgnoreCase(venue.getName()) &&
                        existingVenue.getAddress().equalsIgnoreCase(venue.getAddress())
        );
        if (isDuplicate) {
            throw new IllegalArgumentException("Duplicate venue found with name and address.");
        }
    }

    // 获取特定时间可用场地
    public List<Venue> getAvailableVenues(Date date, Date time) {
        return venueRepository.findAllByDateTime(date, time);
    }
}
