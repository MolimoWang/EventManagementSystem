package org.work1.eventmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.work1.eventmanagement.entity.Venue;

import java.util.Date;
import java.util.List;

@Repository
public interface VenueRepository extends JpaRepository<Venue, Long> {

    // 根据 ID 查找 Venue
    Venue findById(long id);

    // 根据 Organiser ID 查找所有 Venue
    @Query("SELECT v FROM Venue v WHERE v.organiser.id = :organiserId")
    List<Venue> findAllByOrganiserId(@Param("organiserId") long organiserId);


    // 根据日期和时间查找所有可用 Venue
    @Query("SELECT v FROM Venue v WHERE v.date = :date AND v.time = :time")
    List<Venue> findAllByDateTime(@Param("date") Date date, @Param("time") Date time);

    // 查找所有 Venue
    @Query("SELECT v FROM Venue v")
    List<Venue> findAll();

    // 根据 Organiser 邮箱查找 Venue
    @Query("SELECT v FROM Venue v WHERE v.organiser.email = :email")
    List<Venue> findAllByEmail(@Param("email") String organiserEmail);

    // 保存 Venue
    @Override
    <S extends Venue> S save(S venue);

    // 删除 Venue
    @Override
    void delete(Venue venue);
}
