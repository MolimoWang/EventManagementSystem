package org.work1.eventmanagement.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.work1.eventmanagement.entity.Event;

public interface EventMapper extends BaseMapper<Event> {

}
