package org.work1.eventmanagement.entity;


import lombok.Data;

/**
 * VenueVO 是为了跟数据库的类分离
 * 增加了 totalCapacity
 * 用来统计 ticketAvailable的数量
 */
@Data
public class VenueVO extends Venue {
   private Integer totalCapacity;
}
