package org.work1.eventmanagement.controller;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.work1.eventmanagement.entity.Event;
import org.work1.eventmanagement.entity.Organizer;
import org.work1.eventmanagement.entity.Ticket;
import org.work1.eventmanagement.repository.OrganizerRepository;
import org.work1.eventmanagement.repository.VenueRepository;
import org.work1.eventmanagement.service.EventService;
import org.work1.eventmanagement.service.TicketService;

@Controller
@RequestMapping("/apis")
public class TicketController {

    @Resource
    private  EventService eventService;


    @Resource
    private TicketService ticketService;
    @Resource
    private OrganizerRepository organizerRepository;

    @Resource
    private VenueRepository venueRepository;



    private void fillModel(Model model){
        // 列表页面
        model.addAttribute("venues",  venueRepository.findAll());
        model.addAttribute("organisers",  organizerRepository.findAll());
        model.addAttribute("eventForm", new Event()); // 用于表单绑定
        model.addAttribute("errorDTO", new ErrorMessageDTO(ErrorType.NONE, ""));
    }


    @GetMapping("/tickets")
    public String getAllTickets(@RequestParam(value = "type",required = false)String type,Model model) {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = servletRequestAttributes.getRequest();
        Object role1 = request.getSession().getAttribute("role");
        model.addAttribute("role", role1);
        if ("myOrg".equals(type)){
            Organizer organizer = (Organizer)request.getSession().getAttribute("username");
            model.addAttribute("events",  ticketService.getTicketsByOrgName(organizer.getUsername()));
        }
        if ("my".equals(type)){
            String username = (String)request.getSession().getAttribute("username");
            model.addAttribute("events",  ticketService.getMyTickets(username));
        }

        if ("admin".equals(type)){
            String username = (String)request.getSession().getAttribute("username");
            model.addAttribute("events",  ticketService.getAllTickets(username));
        }

        fillModel(model);
        return "list_my_tickets";
    }



    @GetMapping("/ticket/edit/{id}")
    @ResponseBody  // 返回 JSON 数据
    public Ticket editVenue(@PathVariable("id") Long id) {
        // 根据 ID 获取 venue 数据
        return ticketService.getById(id);
    }



    @GetMapping("/orderTicket")
    public ResponseEntity<String> orderTicket(@RequestParam("eventId")String eventId, @RequestParam("ticketType")Integer ticketType, Model model) {
            // 假设您已经有服务方法来处理 VenueDTO 的创建
        try{
            ticketService.orderTicket(eventId,ticketType);
        }catch (RuntimeException e){
            return ResponseEntity.ok(e.getMessage());
        }
        return ResponseEntity.ok("order success");
    }




}