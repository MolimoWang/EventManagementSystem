package org.work1.eventmanagement.entity;

public abstract class AvailabilityInfo {
    public String getTicketTypeName(){
        return null;
    }

    public int getNumberAvailable(){
        return 0;
    }
}