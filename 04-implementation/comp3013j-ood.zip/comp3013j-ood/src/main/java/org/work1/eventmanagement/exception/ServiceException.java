package org.work1.eventmanagement.exception;

/**
 * @author zoumy9
 * @date 2024-11-28
 **/
public class ServiceException extends Exception {
    private String msg;
    public ServiceException(String msg) {
        super(msg);
    }

    public String getMsg() {
        return msg;
    }
}
