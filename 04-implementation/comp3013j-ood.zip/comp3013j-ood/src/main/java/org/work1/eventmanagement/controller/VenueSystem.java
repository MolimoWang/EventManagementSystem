package org.work1.eventmanagement.controller;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.util.JSONPObject;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.NumberUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.work1.eventmanagement.entity.Venue;
import org.work1.eventmanagement.entity.VenueVO;
import org.work1.eventmanagement.service.VenueService;
import org.work1.eventmanagement.util.CommonUtil;

// 建议将VenueSystem 改成 VenueController
@Controller
@Slf4j
public class VenueSystem {

    public VenueService venueService;
    @Autowired
    public VenueSystem(VenueService v) {
        this.venueService = v;
    }

    private void fillModel(Model model){
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = servletRequestAttributes.getRequest();
        Object role1 = request.getSession().getAttribute("role");
        // 列表页面
        model.addAttribute("venues",  venueService.getVenues());
        model.addAttribute("venueForm", new Venue()); // 用于表单绑定
        model.addAttribute("errorDTO", new ErrorMessageDTO(ErrorType.NONE, ""));
        model.addAttribute("role", role1);
    }

    /**
     * 查询列表并且跳转到列表页面
     * @return
     */
    @GetMapping("/venue")
    public String listMyVenues(Model model) {
        try {
            fillModel(model);
            // 返回 Thymeleaf 列表页面
            return "list_my_venues";
        } catch (Exception e) {
            model.addAttribute("error", "Error occurred: " + e.getMessage());
            return "errorPage"; // 显示错误页面
        }
    }

    /**
     * 处理新增或编辑场地
     */
    @PostMapping("/venue")
    public String createVenue(@ModelAttribute VenueDTO venueDTO, Model model) {
        try {
            // 打印前端传入参数的日志
            ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            HttpServletRequest request = servletRequestAttributes.getRequest();
            Object role1 = request.getSession().getAttribute("role");
            System.out.println("传入数据: \n" + venueDTO.toString());
            // 假设您已经有服务方法来处理 VenueDTO 的创建
            boolean isCreate = (venueDTO.getId() == null);
            venueService.createVenue(venueDTO);
            // 返回首页列表
            model.addAttribute("venueForm", new Venue()); // 用于表单绑定
            model.addAttribute("venues",  venueService.getVenues());
            model.addAttribute("role", role1);
            model.addAttribute("message", "Venue '" + venueDTO.getName() + "'" +
                    (isCreate ? " created successfully!" : " update successfully!"));
        } catch (Exception e) {
            // 捕获并处理异常，避免发生 500 错误
            model.addAttribute("venueForm", new Venue()); // 用于表单绑定
            model.addAttribute("venues",  venueService.getVenues());
            model.addAttribute("error", "Create Failed! Reason : create venue: " + e.getMessage());
            e.printStackTrace(); // 打印日志来帮助排查问题
        }
        // 重定向到 Thymeleaf 列表页面
        return "list_my_venues";
    }

    // 编辑表单填充
    @GetMapping("/venue/{id}")
    public String editVenue(@PathVariable Long id, Model model) {
        Venue venue = venueService.getVenue(id);
        model.addAttribute("venueForm", venue); // 填充表单
        model.addAttribute("venues",  venueService.getVenues()); // 页面列表
        return "list_my_venues"; // 返回同一个页面
    }

    // 获取特定 venue 的数据并打开编辑弹窗
    @GetMapping("/edit/{id}")
    @ResponseBody  // 返回 JSON 数据
    public VenueVO editVenue(@PathVariable("id") Long id) {
        // 根据 ID 获取 venue 数据
        Venue venue = venueService.getVenue(id);
        VenueVO vo = new VenueVO();
        BeanUtils.copyProperties(venue, vo);
        Integer capacity = 0;
        if(CommonUtil.isNumeric(venue.getAvailableNumber1())) {
            capacity += NumberUtils.parseNumber(venue.getAvailableNumber1(), Integer.class);
        }
        if(CommonUtil.isNumeric(venue.getAvailableNumber2())) {
            capacity += NumberUtils.parseNumber(venue.getAvailableNumber2(), Integer.class);
        }
        vo.setTotalCapacity(capacity);
        return vo;  // 返回 venue 数据
    }

    // 删除场地
    @GetMapping("/delete/{id}")
    public String deleteVenue(@PathVariable Long id, Model model) {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = servletRequestAttributes.getRequest();
        Object role1 = request.getSession().getAttribute("role");

        if (!"ADMIN".equals(role1)){
            model.addAttribute("venueForm", new Venue()); // 用于表单绑定
            model.addAttribute("venues",  venueService.getVenues());
            model.addAttribute("message", "no auth to exec this method");
            model.addAttribute("role", role1);
            return "list_my_venues";
        }

        Venue venue = venueService.deleteVenue(id);
        model.addAttribute("venueForm", new Venue()); // 用于表单绑定
        model.addAttribute("venues",  venueService.getVenues());
        model.addAttribute("message", "Venue '" + venue.getName() + "' Delete successfully!");
        model.addAttribute("role", role1);
        return "list_my_venues"; // 删除后重定向回列表页面
    }

//    // View details of a specific venue
//    public String viewVenue(Long venueId, Model model) {
//        // Logic to retrieve venue details using the venueId
//        VenueDTO venue = findVenueById(venueId);
//        model.addAttribute("venue", venue);
//        return "viewVenueDetails"; // Return the view name
//    }
//
//    // Update an existing venue
//    public String updateVenue(VenueDTO venueAlterDTO, Model model) {
//        // Logic to update the venue details
//        updateVenueInDatabase(venueAlterDTO);
//        model.addAttribute("message", "Venue updated successfully!");
//        return "venueUpdatedView"; // Return the view name
//    }
//
//    // Delete a specific venue
//    public String deleteVenue(Long venueId, Model model) {
//        // Logic to delete the venue
//        deleteVenueFromDatabase(venueId);
//        model.addAttribute("message", "Venue deleted successfully!");
//        return "venueDeletedView"; // Return the view name
//    }
//
//    // List all venues owned by a specific organizer
//    public String listMyVenues(Long organiserId, Model model) {
//        // Logic to retrieve venues for the organizer
//        List<VenueDTO> myVenues = findVenuesByOrganizer(organiserId);
//        model.addAttribute("myVenues", myVenues);
//        return "list_my_venues"; // Return the view name
//    }
//
//    // List all venues
//    public String listVenues(Model model) {
//        // Logic to retrieve all venues
//        List<VenueDTO> venues = findAllVenues();
//        model.addAttribute("venues", venues);
//        return "listVenues"; // Return the view name
//    }

//    // List available venues for a specific date and time
//    public String listAvailableVenues(Date date, Time time, Model model) {
//        // Logic to find available venues
//        List<VenueDTO> availableVenues = findAvailableVenues(date, time);
//        model.addAttribute("availableVenues", availableVenues);
//        return "listAvailableVenues"; // Return the view name
//    }
//
//    // Example placeholder methods for database/repository interaction
//    private VenueDTO findVenueById(Long venueId) {
//        // Placeholder logic to retrieve a venue by its ID
//        return new VenueDTO("Sample Venue", "123 Main Street", null,null,null,null,null,null);
//    }
//
//    private void updateVenueInDatabase(VenueDTO venueAlterDTO) {
//        // Placeholder logic to update a venue in the database
//    }
//
//    private void deleteVenueFromDatabase(Long venueId) {
//        // Placeholder logic to delete a venue from the database
//    }
//
//    private List<VenueDTO> findVenuesByOrganizer(Long organiserId) {
//        // Placeholder logic to retrieve venues for a specific organizer
//        return List.of(new VenueDTO("Venue 1", "456 Oak Avenue", null,null,null,null,null,null));
//    }
//
//    private List<VenueDTO> findAllVenues() {
//        // Placeholder logic to retrieve all venues
//        return List.of(new VenueDTO("Venue 1", "456 Oak Avenue", null,null,null,null,null,null),
//                new VenueDTO("Venue 2", "789 Pine Road", null,null,null,null,null,null));
//    }
//
//    private List<VenueDTO> findAvailableVenues(Date date, Time time) {
//        // Placeholder logic to find available venues for a specific date and time
//        return List.of(new VenueDTO("Available Venue", "123 Maple Street", null,null,null,null,null,null));
//    }
}
