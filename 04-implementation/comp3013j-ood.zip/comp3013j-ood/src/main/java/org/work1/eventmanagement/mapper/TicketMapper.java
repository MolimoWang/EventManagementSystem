package org.work1.eventmanagement.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.work1.eventmanagement.entity.Event;
import org.work1.eventmanagement.entity.Ticket;

public interface TicketMapper extends BaseMapper<Ticket> {

}
