package org.work1.eventmanagement.entity;


import com.baomidou.mybatisplus.annotation.TableField;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Time;
import java.util.Date;
import java.util.List;

@Entity // 指定这是一个 JPA 实体类
@Table(name = "venues") // 指定表名
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class Venue {
    @Id // 主键
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 自动生成ID
    private Long id;
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    private Date date;
    private Time time;
    @Column(nullable = false) // 指定非空字段
    private String name;

    @Column(nullable = false)
    private String address;

    private String contactName;

    private String contactPhoneNumber;

    private String contactEmail;

    private String ticketTypeName1;
    private String ticketTypeName2;
    private String availableNumber1;
    private String availableNumber2;



    @ManyToOne
    @JoinColumn(name = "organiser_id", nullable = false)
    private Organizer organiser;


    @TableField(exist = false)
    @Transient
    private List<Event> eventList;




}
